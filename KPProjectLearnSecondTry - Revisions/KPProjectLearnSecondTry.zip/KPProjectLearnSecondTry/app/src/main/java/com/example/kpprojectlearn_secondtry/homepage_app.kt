package com.example.kpprojectlearn_secondtry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_homepage_app.*
import kotlinx.android.synthetic.main.activity_login.*


class homepage_app : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage_app)

        val profileName = intent.getStringExtra("Username")
        wellcome_fullname.setText(profileName)

    }


}
