package com.example.kpprojectlearn_secondtry

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_mobile__check.view.*
import org.json.JSONObject


abstract class customAdapter(private val PhoneUsername: List<JSONObject>) : RecyclerView.Adapter<phoneHolder>(), ListAdapter {
    override fun onCreateViewHolder(viewGroup: ViewGroup, p1 : Int): phoneHolder {
        return phoneHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.activity_mobile__check,viewGroup,false))
    }

    override fun getItemCount(): Int = PhoneUsername.size

    override fun onBindViewHolder(holder: phoneHolder, position: Int) {
        holder.bindPhone(PhoneUsername)
    }
}

class phoneHolder(view: View) : RecyclerView.ViewHolder(view){
    private val numberName = view.answer_data

    fun bindPhone(nama_hp: List<JSONObject>){
        numberName.text = nama_hp.toString()
    }
}