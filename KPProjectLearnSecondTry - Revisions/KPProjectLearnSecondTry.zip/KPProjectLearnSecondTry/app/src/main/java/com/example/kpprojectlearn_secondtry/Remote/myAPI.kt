package com.example.kpprojectlearn_secondtry.Remote

import android.database.Observable
import com.example.kpprojectlearn_secondtry.Model.APIResponse
import com.example.kpprojectlearn_secondtry.Model.phoneUser
import retrofit2.Call
import retrofit2.http.*

interface myAPI{
    @FormUrlEncoded
    @POST("registerAPI.php")
    fun registerUser(@Field("email")email:String,@Field("username")username:String,
                     @Field("fullname")fullname:String,@Field("mobilephone") mobilephone:String,
                     @Field("password") password: String):Call<APIResponse>

    @FormUrlEncoded
    @POST("login.php")
    fun loginUser(@Field("email")email:String,@Field("password") password:String):Call<APIResponse>

    @FormUrlEncoded
    @POST("register_phone.php")
    fun registerPhoneUser(@Field("no_hp")no_hp:String,@Field("nama_hp") nama_hp:String) :Call<APIResponse>

    @FormUrlEncoded
    @POST("search_phone.php")
    fun showPhoneUser(@Field("no_hp")phonenumber_check:String) :Call<APIResponse>

//    @GET("search_phone.php")
//    fun showPhoneUser(@Query("no_hp")phonenumber_check: String) : Call<phoneUser>
}

