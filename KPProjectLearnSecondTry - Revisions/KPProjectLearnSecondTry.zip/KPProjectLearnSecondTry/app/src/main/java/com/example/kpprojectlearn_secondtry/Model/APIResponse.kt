package com.example.kpprojectlearn_secondtry.Model

class APIResponse {
    var error:Boolean=false
    var uid:String?=null
    var error_msg:String?=null
    var User:User?=null
    var no_hp:String?=null
    var nama_hp:String?=null
}
