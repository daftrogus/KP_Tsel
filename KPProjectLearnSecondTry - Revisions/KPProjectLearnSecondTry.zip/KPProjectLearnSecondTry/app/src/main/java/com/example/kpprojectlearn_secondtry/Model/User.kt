package com.example.kpprojectlearn_secondtry.Model

class User {
    var name:String=""
    var email:String=""
    var create_at:String=""
    var updated_at:String=""
}