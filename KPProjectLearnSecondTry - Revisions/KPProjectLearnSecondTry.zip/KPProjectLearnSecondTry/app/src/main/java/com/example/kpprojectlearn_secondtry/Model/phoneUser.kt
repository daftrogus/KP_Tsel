package com.example.kpprojectlearn_secondtry.Model

import android.app.DownloadManager
import android.app.SearchableInfo
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import retrofit2.http.Query

public class phoneUser{
    val nama_hp:String
        get() {
            return nama_hp
        }
//    constructor(nama_hp : String){
//        this.nama_hp = nama_hp
//    }
//    constructor()
}

// ini...? iya aku liat nya di internet ditampung di class ini tapi dia gapernah mau ngasilin jsonnya padahal url yang kukirim dari @GET udah bener
// Aku liat request jsonnya dimana? yang udah diakses?